﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Payments.AuthorizeNet.Models
{
    public class IpnModel : BaseNopModel
    {
    }
}
