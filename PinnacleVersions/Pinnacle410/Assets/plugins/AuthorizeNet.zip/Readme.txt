1. 'Nop.Plugin.Payments.AuthorizeNet' directory contains source code.
2. 'Payments.AuthorizeNet' contains binaries. Just drop it into \Plugins directory on your server.