1. 'Nop.Plugin.Shipping.Fedex' directory contains source code.
2. 'Shipping.Fedex' contains binaries. Just drop it into \Plugins directory on your server.