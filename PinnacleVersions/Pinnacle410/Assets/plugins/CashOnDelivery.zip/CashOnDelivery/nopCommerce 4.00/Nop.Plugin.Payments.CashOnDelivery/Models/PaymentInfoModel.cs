﻿using Nop.Web.Framework.Mvc.Models;

namespace Nop.Plugin.Payments.CashOnDelivery.Models
{
    public class PaymentInfoModel : BaseNopModel
    {
        public string DescriptionText { get; set; }
    }
}