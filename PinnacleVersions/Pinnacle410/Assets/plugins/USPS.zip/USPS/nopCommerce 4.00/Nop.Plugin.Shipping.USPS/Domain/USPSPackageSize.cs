﻿//------------------------------------------------------------------------------
// Contributor(s): RJH 08/07/2009. 
//------------------------------------------------------------------------------

namespace Nop.Plugin.Shipping.USPS.Domain
{
    internal enum USPSPackageSize
    {
        Regular,
        Large,
    }
}
