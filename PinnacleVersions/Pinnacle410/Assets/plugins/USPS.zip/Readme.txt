1. 'Nop.Plugin.Shipping.USPS' directory contains source code.
2. 'Shipping.USPS' contains binaries. Just drop it into \Plugins directory on your server.